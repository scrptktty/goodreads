# goodreads
Displays listings on Good Reads of loan availability of ebooks and audiobooks through your local library's Overdrive account.

# Building

Install web-ext

`npm install --global web-ext`

Build the Extension

`web-ext build`

Install the Extension

Open "about:debugging#addons"

